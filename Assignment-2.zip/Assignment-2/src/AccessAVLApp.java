import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;

/**
* Class to run AVL tree 
*
* @author Jess Rosengarten
* @version 1.0
*/
public class AccessAVLApp {

    static AVLTree<String> alvTree;
    static int index;
    static List<String> slist;
    public static void main(String[] args ) throws FileNotFoundException{
        String filename = (args.length <= 1) ? "oklist.txt" : args[1];
        ReadFile object = new ReadFile(filename);
        alvTree = object.getTree();
        object.alvTree();
        slist = Arrays.asList(object.slist);
        
        if (args.length >= 1){
            String studentID = args[0];
            System.out.println(printStudent(studentID));
            System.out.println("insertcount is " + object.iCountList[index]);
            System.out.println("opCount is " + alvTree.opCount);
        } else {
            printAll();
 
        }
          
    }
        
    /**
    * Print all students
    */
    static void printAll(){
        tree.treeOrder();
    }

    static String printStudent(String studentID){
    /**
    * Print single stundent
    *
    * @param studentID student number
    */
        BinaryTreeNode<String> foundNode = tree.find(studentID);
        if (foundNode != null){
            index = slist.indexOf(foundNode.data);
            String[] b = foundNode.data.split(" ");
            return b[1] + " " + b[2];
        }
        
        return "Access denied!";
    } 
}

    

