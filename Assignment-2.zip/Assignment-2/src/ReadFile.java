/**
*
* @author Jess Rosengarten
* @version 1.0
*/
import java.io.File; 
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFile {
    File myObj;
    Scanner myReader;
    String[] slist;
    AVLTree<String> tree;
    int[] iCountList;

    ReadFile(String filename) throws FileNotFoundException{
        myObj = new File("files/" + filename);
        myReader = new Scanner(myObj);
        slist = new String[5000];
        tree = new AVLTree<String>();
        iCountList = new int[5000];
    }
    
    void tree(){
        int i = 0;
        while (myReader.hasNextLine()) {
          String data = myReader.nextLine();
          tree.insert(data.toString());
          slist[i] = data.toString();
          iCountList[i] = tree.insertcount;
          i++;
        } 
    }


    public AVLTree<String> getTree(){
        return this.tree;
    }

}